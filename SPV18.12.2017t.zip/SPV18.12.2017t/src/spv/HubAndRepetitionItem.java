//********************************************************************/
//* Copyright (C) 2017                                               */
//* FILIP CERNATESCU : milpgame at yahoo.com                         */
//* License terms: MIT-License 	                                     */
//********************************************************************/

package spv;
import spv.gen.DemonstrationConstants;
import spv.gen.DemonstrationItem;
import java.util.ArrayList;
import java.util.List;

public class HubAndRepetitionItem {
    public HubAndRepetitionItem()
    {
     
    }
    public DemonstrationItem item=null;
    public List<String> path=null;

}