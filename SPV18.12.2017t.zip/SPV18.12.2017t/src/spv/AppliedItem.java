//********************************************************************/
//* Copyright (C) 2017                                               */
//* FILIP CERNATESCU : milpgame at yahoo.com                         */
//* License terms: MIT-License 	                                     */
//********************************************************************/

package spv;
import spv.gen.DemonstrationConstants;
import java.io.Serializable;


public class AppliedItem implements java.io.Serializable {
   
    public String name="";
    public int type=DemonstrationConstants.THEOREM_FROM_COMPOSED_THEOREM;
    

}
